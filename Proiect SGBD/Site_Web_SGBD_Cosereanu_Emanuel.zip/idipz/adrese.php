<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Localuri</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a class="main_bar_active" href="index.php">Localuri</a></li>
        <li><a href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a href="cafenele.php">Cafenele</a></li>
        <li><a href="restaurante.php">Restaurante</a></li>
        <li><a href="cofetarii.php">Cofetarii</a></li>
        <li><a href="terase.php">Terase</a></li>
        <li><a href="gelaterii.php">Gelaterii</a></li>
        <li><a href="programe_localuri.php">Programe</a></li>
        <li><a class="second_bar_active" href="adrese.php">Adrese</a></li>
        <li><a href="contacte_localuri.php">Contacte</a></li>
    </ul>

<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
          <th>Judet</th>
          <th>Oras</th>
          <th>Strada</th>
          <th>Numar</th>
          <th>Cod postal</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT l.nume, j.nume_judet, o.nume_oras, a.strada, a.numar, a.cod_postal FROM localuri l JOIN adrese a ON l.id_local = a.id_local JOIN coduri_postale cp ON a.cod_postal = cp.cod_postal JOIN orase o ON cp.id_oras = o.id_oras JOIN judete j ON o.id_judet = j.id_judet";
          $adrese = mysqli_query($conn, $sql);

          if($adrese && mysqli_num_rows($adrese) > 0)
          {
            while($adresa = mysqli_fetch_assoc($adrese))
            {
              echo "<tr>";
                        echo "<td>{$adresa['nume']}</td>";
                        echo "<td>{$adresa['nume_judet']}</td>";
                        echo "<td>{$adresa['nume_oras']}</td>";
                        echo "<td>{$adresa['strada']}</td>";
                        echo "<td>{$adresa['numar']}</td>";
                        echo "<td>{$adresa['cod_postal']}</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>