<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Localuri</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a class="main_bar_active" href="index.php">Localuri</a></li>
        <li><a href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a href="cafenele.php">Cafenele</a></li>
        <li><a href="restaurante.php">Restaurante</a></li>
        <li><a href="cofetarii.php">Cofetarii</a></li>
        <li><a href="terase.php">Terase</a></li>
        <li><a href="gelaterii.php">Gelaterii</a></li>
        <li><a href="programe_localuri.php">Programe</a></li>
        <li><a href="adrese.php">Adrese</a></li>
        <li><a class="second_bar_active" href="contacte_localuri.php">Contacte</a></li>
    </ul>

<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
          <th>Mail</th>
          <th>Telefon</th>
          <th>Skype</th>
          <th>Whatsapp</th>
          <th>Telegram</th>
          <th>Facebook</th>
          <th>Instagram</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT l.nume, c.mail, c.nr_telefon, c.skype, c.whatsapp, c.telegram, c.facebook, c.instagram FROM contacte c JOIN localuri l ON c.id_local = l.id_local";
          $contacte = mysqli_query($conn, $sql);

          if($contacte && mysqli_num_rows($contacte) > 0)
          {
            while($contact = mysqli_fetch_assoc($contacte))
            {
              echo "<tr>";
                        echo "<td>{$contact['nume']}</td>";
                        echo "<td class='links'>{$contact['mail']}</td>";
                        echo "<td>{$contact['nr_telefon']}</td>";
                        echo "<td>{$contact['skype']}</td>";
                        echo "<td>{$contact['whatsapp']}</td>";
                        echo "<td class='links'>{$contact['telegram']}</td>";
                        echo "<td class='links'>{$contact['facebook']}</td>";
                        echo "<td class='links'>{$contact['instagram']}</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>