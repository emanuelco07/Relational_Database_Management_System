<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Localuri</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a class="main_bar_active" href="index.php">Localuri</a></li>
        <li><a href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a href="cafenele.php">Cafenele</a></li>
        <li><a href="restaurante.php">Restaurante</a></li>
        <li><a href="cofetarii.php">Cofetarii</a></li>
        <li><a href="terase.php">Terase</a></li>
        <li><a class="second_bar_active" href="gelaterii.php">Gelaterii</a></li>
        <li><a href="programe_localuri.php">Programe</a></li>
        <li><a href="adrese.php">Adrese</a></li>
        <li><a href="contacte_localuri.php">Contacte</a></li>
    </ul>

<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
          <th>Produse organice</th>
          <th>Laborator propriu</th>
          <th>Este artizanala</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT l.nume, g.organice, g.laborator, g.artizanala FROM localuri l JOIN gelaterii g ON l.id_local = g.id_local";
          $gelaterii = mysqli_query($conn, $sql);

          if($gelaterii && mysqli_num_rows($gelaterii) > 0)
          {
            while($gelaterie = mysqli_fetch_assoc($gelaterii))
            {
                echo "<tr>";
                        echo "<td>{$gelaterie['nume']}</td>";
                        if ($gelaterie['organice'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
                        if ($gelaterie['laborator'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
                        if ($gelaterie['artizanala'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
                echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>