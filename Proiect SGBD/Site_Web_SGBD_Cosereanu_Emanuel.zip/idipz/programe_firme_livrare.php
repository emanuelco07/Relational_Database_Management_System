<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Firme livrare</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a href="index.php">Localuri</a></li>
        <li><a class="main_bar_active" href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a href="contacte_firme.php">Contacte</a></li>
        <li><a href="zone_acoperire.php">Zone acoperire</a></li>
        <li><a class="second_bar_active" href="programe_firme_livrare.php">Programe</a></li>
    </ul>
<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
          <th>Deschide la</th>
          <th>Inchide la</th>
          <th>Zi</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT f.nume, p.ora_inceput, p.ora_final, p.zi FROM firme_livrare f JOIN programe p ON f.id_firma = p.id_firma ORDER BY f.nume";
          $programe = mysqli_query($conn, $sql);

          if($programe && mysqli_num_rows($programe) > 0)
          {
            while($program = mysqli_fetch_assoc($programe))
            {
              echo "<tr>";
                        echo "<td>{$program['nume']}</td>";
                        echo "<td>{$program['ora_inceput']}</td>";
                        echo "<td>{$program['ora_final']}</td>";
                        echo "<td>{$program['zi']}</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>