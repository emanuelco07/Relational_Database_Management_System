<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Localuri</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a class="main_bar_active" href="index.php">Localuri</a></li>
        <li><a href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a href="adrese_email.php">Adrese email</a></li>
        <li><a href="animale_companie.php">Localuri ce permit animale de companie</a></li>
        <li><a class="third_bar_active" href="firme_livrare_proprii.php">Localuri ce nu au firma de livrare proprie</a></li>
        <li><a href="cafe.php">Cafenele si cofetarii</a></li>
        <li><a href="restaurante_ieftine.php">Restaurante ce livreaza cu Bolt Food si au cost standard < 17 RON</a></li>
    </ul>

<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT l.nume FROM localuri l WHERE NOT EXISTS ( SELECT NULL FROM localuri_firme_livrare lf JOIN firme_livrare f ON lf.id_firma = f.id_firma WHERE lf.id_local = l.id_local AND f.nume = l.nume)";
          $localuri = mysqli_query($conn, $sql);

          if($localuri && mysqli_num_rows($localuri) > 0)
          {
            while($local = mysqli_fetch_assoc($localuri))
            {
              echo "<tr>";
                        echo "<td>{$local['nume']}</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>