<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Localuri firme livrare</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a href="index.php">Localuri</a></li>
        <li><a href="firme_livrare.php">Firme livrare</a></li>
        <li><a class="main_bar_active" href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>
    <ul>
        <li><a class="third_bar_active" href="localuri_livreaza_duminica.php">Localuri ce livreaza duminica</a></li>
    </ul>
<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume local</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT DISTINCT l.nume FROM (SELECT id_local FROM programe WHERE zi = 'Duminica') pl JOIN localuri l ON l.id_local = pl.id_local JOIN localuri_firme_livrare lf ON l.id_local = lf.id_local JOIN (SELECT id_firma FROM programe WHERE zi = 'Duminica') pf ON lf.id_firma = pf.id_firma;";
          $localuri_firme_livrare = mysqli_query($conn, $sql);

          if($localuri_firme_livrare && mysqli_num_rows($localuri_firme_livrare) > 0)
          {
            while($localuri_firme = mysqli_fetch_assoc($localuri_firme_livrare))
            {
              echo "<tr>";
                        echo "<td>{$localuri_firme['nume']}</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>