<?php
$host = "localhost";
$username = "root";
$password = "root";
$dbname = "idipz";

// conectarea la baza de date
$conn = mysqli_connect($host, $username, $password, $dbname);

if (!$conn) 
{
    die("Conexiune eșuată: " . mysqli_connect_error());
}
?>
