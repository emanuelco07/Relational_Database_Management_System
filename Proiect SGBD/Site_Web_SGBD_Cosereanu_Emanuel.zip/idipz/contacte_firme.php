<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Firme livrare</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a href="index.php">Localuri</a></li>
        <li><a class="main_bar_active" href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a class="second_bar_active" href="contacte_firme.php">Contacte</a></li>
        <li><a href="zone_acoperire.php">Zone acoperire</a></li>
        <li><a href="programe_firme_livrare.php">Programe</a></li>
    </ul>
<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
          <th>Mail</th>
          <th>Telefon</th>
          <th>Skype</th>
          <th>Whatsapp</th>
          <th>Telegram</th>
          <th>Facebook</th>
          <th>Instagram</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT f.nume, c.mail, c.nr_telefon, c.skype, c.whatsapp, c.telegram, c.facebook, c.instagram FROM contacte c JOIN firme_livrare f ON c.id_firma = f.id_firma";
          $contacte = mysqli_query($conn, $sql);

          if($contacte && mysqli_num_rows($contacte) > 0)
          {
            while($contact = mysqli_fetch_assoc($contacte))
            {
              echo "<tr>";
                        echo "<td>{$contact['nume']}</td>";
                        echo "<td class='links'>{$contact['mail']}</td>";
                        echo "<td>{$contact['nr_telefon']}</td>";
                        echo "<td>{$contact['skype']}</td>";
                        echo "<td>{$contact['whatsapp']}</td>";
                        echo "<td class='links'>{$contact['telegram']}</td>";
                        echo "<td class='links'>{$contact['facebook']}</td>";
                        echo "<td class='links'>{$contact['instagram']}</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>