<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Localuri</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a class="main_bar_active" href="index.php">Localuri</a></li>
        <li><a href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a href="cafenele.php">Cafenele</a></li>
        <li><a href="restaurante.php">Restaurante</a></li>
        <li><a href="cofetarii.php">Cofetarii</a></li>
        <li><a href="terase.php">Terase</a></li>
        <li><a href="gelaterii.php">Gelaterii</a></li>
        <li><a class="second_bar_active" href="programe_localuri.php">Programe</a></li>
        <li><a href="adrese.php">Adrese</a></li>
        <li><a href="contacte_localuri.php">Contacte</a></li>
    </ul>

<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
          <th>Deschide la</th>
          <th>Inchide la</th>
          <th>Zi</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT l.nume, p.ora_inceput, p.ora_final, p.zi FROM localuri l JOIN programe p ON l.id_local = p.id_local ORDER BY l.nume";
          $programe = mysqli_query($conn, $sql);

          if($programe && mysqli_num_rows($programe) > 0)
          {
            while($program = mysqli_fetch_assoc($programe))
            {
              echo "<tr>";
                        echo "<td>{$program['nume']}</td>";
                        echo "<td>{$program['ora_inceput']}</td>";
                        echo "<td>{$program['ora_final']}</td>";
                        echo "<td>{$program['zi']}</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>