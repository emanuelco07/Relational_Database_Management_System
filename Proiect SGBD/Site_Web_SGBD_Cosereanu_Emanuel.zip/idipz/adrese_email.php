<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Localuri</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a class="main_bar_active" href="index.php">Localuri</a></li>
        <li><a href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a class="third_bar_active" href="adrese_email.php">Adrese email</a></li>
        <li><a href="animale_companie.php">Localuri ce permit animale de companie</a></li>
        <li><a href="firme_livrare_proprii.php">Localuri ce nu au firma de livrare proprie</a></li>
        <li><a href="cafe.php">Cafenele si cofetarii</a></li>
        <li><a href="restaurante_ieftine.php">Restaurante ce livreaza cu Bolt Food si au cost standard < 17 RON</a></li>
    </ul>

<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
          <th>Email</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT DISTINCT l.nume, c.mail FROM localuri l JOIN contacte c ON l.id_local = c.id_local;";
          $emailuri = mysqli_query($conn, $sql);

          if($emailuri && mysqli_num_rows($emailuri) > 0)
          {
            while($email = mysqli_fetch_assoc($emailuri))
            {
              echo "<tr>";
                        echo "<td>{$email['nume']}</td>";
                        echo "<td>{$email['mail']}</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>