<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Localuri</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a class="main_bar_active" href="index.php">Localuri</a></li>
        <li><a href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a href="cafenele.php">Cafenele</a></li>
        <li><a class="second_bar_active" href="restaurante.php">Restaurante</a></li>
        <li><a href="cofetarii.php">Cofetarii</a></li>
        <li><a href="terase.php">Terase</a></li>
        <li><a href="gelaterii.php">Gelaterii</a></li>
        <li><a href="programe_localuri.php">Programe</a></li>
        <li><a href="adrese.php">Adrese</a></li>
        <li><a href="contacte_localuri.php">Contacte</a></li>
    </ul>

<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
          <th>Evenimente</th>
          <th>Bucatarie</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT l.nume, r.evenimente, r.bucatarie FROM localuri l JOIN restaurante r ON l.id_local = r.id_local";
          $restaurante = mysqli_query($conn, $sql);

          if($restaurante && mysqli_num_rows($restaurante) > 0)
          {
            while($restaurant = mysqli_fetch_assoc($restaurante))
            {
              echo "<tr>";
                        echo "<td>{$restaurant['nume']}</td>";
                        if ($restaurant['evenimente'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
                        echo "<td>{$restaurant['bucatarie']}</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>