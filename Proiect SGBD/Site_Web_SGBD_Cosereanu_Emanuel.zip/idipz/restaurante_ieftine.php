<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Localuri</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a class="main_bar_active" href="index.php">Localuri</a></li>
        <li><a href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a href="adrese_email.php">Adrese email</a></li>
        <li><a href="animale_companie.php">Localuri ce permit animale de companie</a></li>
        <li><a href="firme_livrare_proprii.php">Localuri ce nu au firma de livrare proprie</a></li>
        <li><a href="cafe.php">Cafenele si cofetarii</a></li>
        <li><a class="third_bar_active" href="restaurante_ieftine.php">Restaurante ce livreaza cu Bolt Food si au cost standard < 17 RON</a></li>
    </ul>

<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
            $sql1 = "CREATE TEMPORARY TABLE firme_bolt AS SELECT id_firma FROM firme_livrare WHERE nume = 'Bolt Food';";

            if (!$conn->query($sql1)) {
                die("Eroare la crearea tabelului temporar firme_bolt: " . $conn->error);
            }

            $sql2 = "CREATE TEMPORARY TABLE livrari_ieftine AS SELECT id_local, id_firma FROM localuri_firme_livrare WHERE cost_standard < 17;";

            if (!$conn->query($sql2)) {
                die("Eroare la crearea tabelului temporar livrari_ieftine: " . $conn->error);
            }

            $sql3 = "SELECT l.nume FROM localuri l JOIN restaurante r ON l.id_local = r.id_local JOIN livrari_ieftine lf ON l.id_local = lf.id_local JOIN firme_bolt f ON lf.id_firma = f.id_firma;";

          $ieftine = mysqli_query($conn, $sql3);

          if($ieftine && mysqli_num_rows($ieftine) > 0)
          {
            while($ieftin = mysqli_fetch_assoc($ieftine))
            {
              echo "<tr>";
                        echo "<td>{$ieftin['nume']}</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>