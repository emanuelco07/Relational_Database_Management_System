<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Firme livrare</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a href="index.php">Localuri</a></li>
        <li><a class="main_bar_active" href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a href="contacte_firme.php">Contacte</a></li>
        <li><a class="second_bar_active" href="zone_acoperire.php">Zone acoperire</a></li>
        <li><a href="programe_firme_livrare.php">Programe</a></li>
    </ul>
<div class="container">
    <table>
      <thead>
        <tr>
          <th>Firma</th>
          <th>Oras</th>
          <th>Raza de livrare de 10 km</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT f.nume,  o.nume_oras, z.imprejurimi_de_10_km FROM orase o JOIN zone_acoperire z ON o.id_oras = z.id_oras JOIN firme_livrare f ON z.id_firma = f.id_firma;";
          $zone_acoperire = mysqli_query($conn, $sql);

          if($zone_acoperire && mysqli_num_rows($zone_acoperire) > 0)
          {
            while($zona_acoperire = mysqli_fetch_assoc($zone_acoperire))
            {
              echo "<tr>";
                        echo "<td>{$zona_acoperire['nume']}</td>";
                        echo "<td>{$zona_acoperire['nume_oras']}</td>";
                        if ($zona_acoperire['imprejurimi_de_10_km'] == 1)
                          echo "<td>DA</td>";
                        else
                          echo "<td>NU</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>