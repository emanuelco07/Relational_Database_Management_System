<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Localuri</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a class="main_bar_active" href="index.php">Localuri</a></li>
        <li><a href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a class="second_bar_active" href="cafenele.php">Cafenele</a></li>
        <li><a href="restaurante.php">Restaurante</a></li>
        <li><a href="cofetarii.php">Cofetarii</a></li>
        <li><a href="terase.php">Terase</a></li>
        <li><a href="gelaterii.php">Gelaterii</a></li>
        <li><a href="programe_localuri.php">Programe</a></li>
        <li><a href="adrese.php">Adrese</a></li>
        <li><a href="contacte_localuri.php">Contacte</a></li>
    </ul>

<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
          <th>Spatiu de lucru</th>
          <th>Produse vegane</th>
          <th>Tip servire</th>
          <th>Originea cafelei</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT l.nume, c.spatiu_de_lucru, c.produse_vegane, c.tip_servire, c.originea_cafelei FROM localuri l JOIN cafenele c ON l.id_local = c.id_local";
          $cafenele = mysqli_query($conn, $sql);

          if($cafenele && mysqli_num_rows($cafenele) > 0)
          {
            while($cafenea = mysqli_fetch_assoc($cafenele))
            {
              echo "<tr>";
                        echo "<td>{$cafenea['nume']}</td>";
                        if ($cafenea['spatiu_de_lucru'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
                        if ($cafenea['produse_vegane'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
                        echo "<td>{$cafenea['tip_servire']}</td>";
                        echo "<td>{$cafenea['originea_cafelei']}</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>