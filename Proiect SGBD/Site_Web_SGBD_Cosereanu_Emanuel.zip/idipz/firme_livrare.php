<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Firme livrare</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a href="index.php">Localuri</a></li>
        <li><a class="main_bar_active" href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a href="contacte_firme.php">Contacte</a></li>
        <li><a href="zone_acoperire.php">Zone acoperire</a></li>
        <li><a href="programe_firme_livrare.php">Programe</a></li>
    </ul>
<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
          <th>Website</th>
          <th>Rating</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT * FROM firme_livrare";
          $firme_livrare = mysqli_query($conn, $sql);

          if($firme_livrare && mysqli_num_rows($firme_livrare) > 0)
          {
            while($firma = mysqli_fetch_assoc($firme_livrare))
            {
              echo "<tr>";
                        echo "<td>{$firma['nume']}</td>";
                        echo "<td>{$firma['website']}</td>";
                        echo "<td>{$firma['rating']}</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>