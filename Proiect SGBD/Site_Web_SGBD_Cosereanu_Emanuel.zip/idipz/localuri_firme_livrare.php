<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Localuri firme livrare</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a href="index.php">Localuri</a></li>
        <li><a href="firme_livrare.php">Firme livrare</a></li>
        <li><a class="main_bar_active" href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>
    <ul>
        <li><a href="localuri_livreaza_duminica.php">Localuri ce livreaza duminica</a></li>
    </ul>

<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume local</th>
          <th>Nume firma</th>
          <th>Cost standard</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT l.nume nume_local, f.nume nume_firma, lf.cost_standard cost FROM localuri l JOIN localuri_firme_livrare lf ON l.id_local = lf.id_local JOIN firme_livrare f ON lf.id_firma = f.id_firma ORDER BY l.nume";
          $localuri_firme_livrare = mysqli_query($conn, $sql);

          if($localuri_firme_livrare && mysqli_num_rows($localuri_firme_livrare) > 0)
          {
            while($localuri_firme = mysqli_fetch_assoc($localuri_firme_livrare))
            {
              echo "<tr>";
                        echo "<td>{$localuri_firme['nume_local']}</td>";
                        echo "<td>{$localuri_firme['nume_firma']}</td>";
                        echo "<td>{$localuri_firme['cost']} RON</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>