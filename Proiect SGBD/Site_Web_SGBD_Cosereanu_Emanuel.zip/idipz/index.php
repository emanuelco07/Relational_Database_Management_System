<?php
session_start();
include('db.php');
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <title>Localuri</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
        <li><a class="main_bar_active" href="index.php">Localuri</a></li>
        <li><a href="firme_livrare.php">Firme livrare</a></li>
        <li><a href="localuri_firme_livrare.php">Localuri firme livrare</a></li>
    </ul>

    <ul>
        <li><a href="cafenele.php">Cafenele</a></li>
        <li><a href="restaurante.php">Restaurante</a></li>
        <li><a href="cofetarii.php">Cofetarii</a></li>
        <li><a href="terase.php">Terase</a></li>
        <li><a href="gelaterii.php">Gelaterii</a></li>
        <li><a href="programe_localuri.php">Programe</a></li>
        <li><a href="adrese.php">Adrese</a></li>
        <li><a href="contacte_localuri.php">Contacte</a></li>
    </ul>

    <ul>
        <li><a href="adrese_email.php">Adrese email</a></li>
        <li><a href="animale_companie.php">Localuri ce permit animale de companie</a></li>
        <li><a href="firme_livrare_proprii.php">Localuri ce nu au firma de livrare proprie</a></li>
        <li><a href="cafe.php">Cafenele si cofetarii</a></li>
        <li><a href="restaurante_ieftine.php">Restaurante ce livreaza cu Bolt Food si au cost standard < 17 RON</a></li>
    </ul>

<div class="container">
    <table>
      <thead>
        <tr>
          <th>Nume</th>
          <th>Permite rezervari</th>
          <th>Ofera livrare</th>
          <th>Are wifi</th>
          <th>Meniu digital</th>
          <th>Parcare</th>
          <th>Permite animale de companie</th>
          <th>Servire la pachet</th>
          <th>Are terasa</th>
        </tr>
      </thead>
      <tbody>
        <?php
          include('db.php');
          $sql = "SELECT * FROM localuri";
          $localuri = mysqli_query($conn, $sql);

          if($localuri && mysqli_num_rows($localuri) > 0)
          {
            while($local = mysqli_fetch_assoc($localuri))
            {
              echo "<tr>";
                        echo "<td>{$local['nume']}</td>";
                        if ($local['rezervare'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
                        if ($local['livrare'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
                        if ($local['wifi'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
                        echo "<td class='links'>{$local['meniu_digital']}</td>";
                        if ($local['parcare'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
                        if ($local['animale_de_companie'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
                        if ($local['servire_la_pachet'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
                        if ($local['terasa'] == 1)
                            echo "<td>DA</td>";
                        else
                            echo "<td>NU</td>";
              echo "</tr>";
            }
          }
          else
                {
                    echo "<tr><td colspan='3'>Nu exista inserari in baza de date!</td></tr>";
                }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>